id 	 = abc@xyz.com
password = 123456
role 	 = admin
	   salesperson
	   user